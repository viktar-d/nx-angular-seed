// gives anyone access to ts-node
// https://github.com/TypeStrong/ts-node#programmatic-usage
module.exports = require('ts-node')
