const background = require('./background')

const HOST = 'CHANGE_ME_HOST'
const PATH = 'CHANGE_ME_PATH'

// immediately connect
background.connect(HOST, PATH)
