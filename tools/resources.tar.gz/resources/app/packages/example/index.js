module.exports = require('./lib/example')
