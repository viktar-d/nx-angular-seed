module.exports = require('coffeescript')
