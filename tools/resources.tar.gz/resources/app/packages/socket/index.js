module.exports = require('./lib/socket')
