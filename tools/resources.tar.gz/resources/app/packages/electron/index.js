require('../coffee/register')

module.exports = require('./lib/electron')
