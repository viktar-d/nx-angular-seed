process.env.CYPRESS_ENV = process.env.CYPRESS_ENV || 'production'
require('./packages/server')